import os, sys


CorrectUsername = "4"
CorrectPassword = "1"
loop = 'true'
while (loop == 'true'):
    username = raw_input("\033[1;96m \x1b[1;93mUsername Of Tool \x1b[1;96m>>>> ")
    if (username == CorrectUsername):
    	password = raw_input("\033[1;96m \x1b[1;93mPassword Of Tool \x1b[1;96m>>>> ")
        if (password == CorrectPassword):
            print "Logged in successfully as " + username
            loop = 'false'
        else:
            print "Wrong Password"
            os.system('xdg-open youtube.com/channel/UCzFviFYCOJI4IwhdVOQTqIw')
    else:
        print "Wrong Username"
        os.system('xdg-open https://t.me/TT_RQ')
def login():
	os.system('clear')
	try:
		toket = open('login.txt','r')
		menu() 
	except (KeyError,IOError):
		os.system('clear')

import os,sys,time


def main():
    time.sleep(1)
    os.system ('clear')
    print '[93m'
    os.system ('figlet Sidra Tools')
    print'[92m================================='
    print'[93m Script By :[93mSidra ELEzz'
    print'[93m Telegram  : [92mhttps://t.me/TT_RQ '
    print'[93m YouTube : [92mTermux Tooks '
    os.system('xdg-open https://youtube.com/channel/UCzFviFYCOJI4IwhdVOQTqIw')
    print'[92m================================='
    print'[92m++++++++++++ [97mTOOLS [92m++++++++++++'
    print'[92m[[93m1[92m] [92mInstagram tool '
    print'[92m[[93m2][92m [93mFollow me on Telegram'
    print'[92m[[93m3[92m] [93mFollow me on Youtube '
    print'[92m[[93m4[92m] [93mFollow me on github'
    print'[92m[[93m5[92m] [93mBot all my own tools'
    print'[92m[[91m0[92m] [91mExit '
    gans = raw_input ('[97m==>[93m ')
    if gans in ['1']:
        time.sleep(1)
        os.system ('bash SidraInsta.sh')
        exit()
    if gans in ['2']:
        time.sleep(1)
        os.system ('xdg-open https://t.me/TT_RQ')
        exit()
    if gans in ['3']:
        time.sleep(1)
        os.system ('xdg-open youtube.com/channel/UCzFviFYCOJI4IwhdVOQTqIw')
        exit()
    if gans in ['4']:
        time.sleep(1)
        os.system ('xdg-open https://github.com/SidraELEzz')
        exit()
    if gans in ['5']:
        time.sleep(1)
        os.system('xdg-open https://t.me/SQ23BOT')
        exit()
    if gans in ['0']:
    	time.sleep(1)
        os.system ('clear')
    print '[93m'
    os.system ('figlet Sidra Tools')
        
main()
 
